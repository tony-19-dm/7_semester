#include <stdio.h>
#include <pthread.h>
#include <sched.h>
#include <sys/neutrino.h>
#include <unistd.h>

volatile int ready = 0;
volatile int detection_flag = 0;

void* high_priority_thread(void* arg) {
    struct sched_param param;
    int policy;
    
    // Получаем текущие параметры планирования
    pthread_getschedparam(pthread_self(), &policy, &param);
    
    ready = 1;
    
    // Устанавливаем тот же приоритет
    pthread_setschedparam(pthread_self(), policy, &param);
    
    detection_flag = 1;
    
    return NULL;
}

void* monitoring_thread(void* arg) {
    uint64_t start, end;
    
    while (!ready) {
        // Ждем готовности
    }
    
    start = ClockCycles();
    
    // Создаем нить с таким же приоритетом
    pthread_t test_thread;
    pthread_create(&test_thread, NULL, high_priority_thread, NULL);
    
    // Мониторим изменение флага
    while (!detection_flag) {
        // Ожидаем
    }
    
    end = ClockCycles();
    
    pthread_join(test_thread, NULL);
    
    printf("Время между созданием нити и установкой флага: %llu циклов\n", 
           (unsigned long long)(end - start));
    
    return NULL;
}

int main() {
    pthread_t monitor;
    
    pthread_create(&monitor, NULL, monitoring_thread, NULL);
    pthread_join(monitor, NULL);
    
    return 0;
}